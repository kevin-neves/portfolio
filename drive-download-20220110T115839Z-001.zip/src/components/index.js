export { default as Header } from './Header/Header';
export { default as Main } from './Main/Main';
export { default as Footer } from './Footer/index';
export { default as Introduction } from './Main/Introduction/Introduction';
export { default as AboutMe } from './Main/AboutMe/AboutMe';
export { default as Skills } from './Main/Skills/Skills';
export { default as Projects } from './Main/Projects/Projects';
